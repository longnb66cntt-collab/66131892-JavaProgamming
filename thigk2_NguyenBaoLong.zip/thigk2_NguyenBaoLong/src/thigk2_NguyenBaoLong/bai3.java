package thigk2_NguyenBaoLong;

public class bai3 {
	import java.io.File;
	import java.io.FileNotFoundException;
	import java.util.ArrayList;
	import java.util.Scanner;


	    /*
	     * TÓM TẮT CÁCH GIẢI:
	     * - Đọc dữ liệu từ file chứa các số thực (mỗi số 1 dòng)
	     * - Lưu các số vào ArrayList
	     * - In danh sách các số ra màn hình
	     * - Nhập số X (ngày sinh)
	     * - Kiểm tra X có tồn tại trong danh sách hay không
	     * - In kết quả
	     */

	    public static void main(String[] args) {
	        ArrayList<Double> ds = new ArrayList<>();

	        try {
	            // Đọc file (đổi tên file nếu cần)
	            File file = new File("data.txt");
	            Scanner scFile = new Scanner(file);

	            // Đọc từng số
	            while (scFile.hasNextDouble()) {
	                ds.add(scFile.nextDouble());
	            }

	            scFile.close();

	        } catch (FileNotFoundException e) {
	            System.out.println("Khong tim thay file!");
	            return;
	        }

	        // In danh sách
	        System.out.println("Danh sach cac so:");
	        for (double x : ds) {
	            System.out.println(x);
	        }

	        // Nhập X (ngày sinh)
	        Scanner sc = new Scanner(System.in);
	        System.out.print("Nhap X (ngay sinh): ");
	        double X = sc.nextDouble();

	        // Kiểm tra tồn tại
	        boolean timThay = false;
	        for (double x : ds) {
	            if (x == X) {
	                timThay = true;
	                break;
	            }
	        }

	        // Kết quả
	        if (timThay) {
	            System.out.println("X co trong danh sach");
	        } else {
	            System.out.println("X khong co trong danh sach");
	        }

	        sc.close();
	}

