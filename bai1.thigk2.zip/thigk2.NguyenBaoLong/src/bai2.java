
public class bai2 {

}
